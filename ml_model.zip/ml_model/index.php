<?php



require_once __DIR__ . '/vendor/autoload.php';
require 'm.php';

use Phpml\Classification\NaiveBayes;

use Phpml\Dataset\CsvDataset;
use Phpml\Classification\KNearestNeighbors;

$dataset=new CsvDataset('dataset/reviews.csv',1,true);

// echo $classifier->predict(["sadsad"]);
$samples=$new_arr;
$labels=$dataset->getTargets();


$classifier = new NaiveBayes();
//train

$classifier ->train($samples,$labels);


//input

$input=[" fantastic hotel fabulous stay sheraton downtown seattle  stayed remodeled union tower king corner room.the room decorated shades chocolate brown caramel cream tasteful roomy clean.the staff helpful courteous  hotel walking distance things downtown seattle  fabulous weekend highly recommend hotel looking stay downtown area"];

// Build the dictionary.
$vectorizer->fit($input);

// Transform the provided text samples into a vectorized list.
$vectorizer->transform($input);

echo $classifier->predict($input)[0];

?>

<html>
    <header></header>


    <body>


    </body>
</html>