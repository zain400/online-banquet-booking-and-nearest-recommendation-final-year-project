<?php
require_once __DIR__ . '/vendor/autoload.php';


use Phpml\FeatureExtraction\TokenCountVectorizer;
use Phpml\Tokenization\WhitespaceTokenizer;
use Phpml\Dataset\CsvDataset;

$vectorizer = new TokenCountVectorizer(new WhitespaceTokenizer());

$dataset=new CsvDataset('dataset/reviews.csv',1,true);




$arr=$dataset->getSamples();

//  var_dump ($dataset->getSamples());


//  echo "old";
  //var_dump($dataset->getSamples());

  
  $new_arr=array();

  for($i=0;$i<count($arr);$i++)
  {
      array_push($new_arr,$arr[$i][0]);
  }

  //var_dump( $new_arr);
 
$vectorizer = new TokenCountVectorizer(new WhitespaceTokenizer());

// Build the dictionary.
 $vectorizer->fit($new_arr);

// Transform the provided text samples into a vectorized list.
 $xxx= $vectorizer->transform($new_arr);
// return $samples = [
//    [0 => 1, 1 => 1, 2 => 2, 3 => 1, 4 => 1],
//    [5 => 1, 6 => 1, 1 => 1, 2 => 1],
//    [5 => 1, 7 => 2, 8 => 1, 9 => 1],
//];



//var_dump( $new_arr);



?>